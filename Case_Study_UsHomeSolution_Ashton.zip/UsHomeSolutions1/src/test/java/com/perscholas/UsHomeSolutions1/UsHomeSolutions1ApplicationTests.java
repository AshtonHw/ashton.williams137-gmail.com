package com.perscholas.UsHomeSolutions1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsHomeSolutions1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
