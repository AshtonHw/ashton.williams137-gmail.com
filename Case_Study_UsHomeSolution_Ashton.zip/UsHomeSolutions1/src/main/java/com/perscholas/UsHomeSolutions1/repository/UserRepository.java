package com.perscholas.UsHomeSolutions1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.perscholas.UsHomeSolutions1.models.User;

public interface UserRepository extends JpaRepository<User, Integer> {


}
