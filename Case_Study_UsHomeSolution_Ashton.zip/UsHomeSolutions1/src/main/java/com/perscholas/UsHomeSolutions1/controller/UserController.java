package com.perscholas.UsHomeSolutions1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.perscholas.UsHomeSolutions1.models.User;
import com.perscholas.UsHomeSolutions1.service.UserService;

@Controller
public class UserController {
	@Autowired
	UserService service;

	@GetMapping("/GetOffer")
	public String showRegister(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "GetOffer";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String Conformation(@ModelAttribute User user) {
		service.save(user);
		return "redirect:/Conformation";
	}
	@RequestMapping("/Conformation")
	public String Conformation() {

		return "Conformation";
	}
	@RequestMapping("/")
	public String index() {
		return "redirect:/homeaddress";
	}

	@RequestMapping("/homeaddress")
	public String home() {

		return "homeaddress";
	}

	@RequestMapping("/AboutUs")
	public String AboutUs() {

		return "AboutUs";
	}

	@RequestMapping("/ContactUs")
	public String ContactUs() {

		return "ContactUs";
	}

}
