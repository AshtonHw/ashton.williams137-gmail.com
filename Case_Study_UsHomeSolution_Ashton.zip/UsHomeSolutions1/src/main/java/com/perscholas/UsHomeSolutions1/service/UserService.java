package com.perscholas.UsHomeSolutions1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.perscholas.UsHomeSolutions1.models.User;
import com.perscholas.UsHomeSolutions1.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repo;
	
	public List<User> listAll(){
		return repo.findAll();
	}
	public User get(int id) {
		return repo.getOne(id);
	}
	
	public void delete(int id) {
		repo.deleteById(id);
	}
	 public void save(User user) {
		 repo.save(user);

}}
