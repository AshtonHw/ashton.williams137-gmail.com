package com.perscholas.UsHomeSolutions1.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	public int getId() {
		return id;
	}

	public User() {
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "NAME", nullable = false, length = 10)
	private String name;
	@Column(name = "email", unique = true, nullable = false, length = 100)
	private String email;
	@Column(name = "phoneNumber", unique = true, nullable = false, length = 100)
	private int phoneNumber;
	@Column(name = "ADDRESS", unique = true, nullable = false, length = 100)
	private String address;

	public String getName()

	{
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	public String getAddress() {
		return address;
	}

	public User(int id, String name, String email, int phoneNumber, String address) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
