package com.perscholas.UsHomeSolutions1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsHomeSolutions1Application {

	public static void main(String[] args) {
		SpringApplication.run(UsHomeSolutions1Application.class, args);
	}

}
